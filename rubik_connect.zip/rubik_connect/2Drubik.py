import tkinter as tk
import random
import socket
import threading
import time

class CubeGUI:
    def __init__(self, master):
        self.master = master
        master.geometry("1400x850")
        
        main = tk.Frame(master,bg="white")
        main.pack(fill="both", expand=True)

        left_panel = tk.Frame(main)   # 左：キューブ＋操作パネル
        left_panel.pack(side="left", padx=20, pady=20)

        right_panel = tk.Frame(main)  # 右：展開図キャンバス
        right_panel.pack(side="right", padx=20, pady=20)
        
        self.timer_running = False
        self.start_time = None
        self.remaining = 60  # 残り秒数

        # タイマー表示
        self.timer_label = tk.Label(master, text="60.00", font=("Helvetica", 60),bg="white",fg="black")
        self.timer_label.place(x=1200, y=10)
        
        self.status_label = tk.Label(root, text="", font=("Helvetica", 60),bg="white",fg="white")
        self.status_label.place(x=800,y=10)
                
        
        # 各面の初期状態（6面、各面3x3のグリッド）
        self.faces = {
            "front": [["white"] * 3 for _ in range(3)],
            "back": [["yellow"] * 3 for _ in range(3)],
            "left": [["orange"] * 3 for _ in range(3)],
            "right": [["red"] * 3 for _ in range(3)],
            "top": [["blue"] * 3 for _ in range(3)],
            "bottom": [["green"] * 3 for _ in range(3)]
        }

        # 各面の中心に指定された色を設定
        self.faces["front"][1][1] = "white"
        self.faces["back"][1][1] = "yellow"
        self.faces["left"][1][1] = "orange"
        self.faces["right"][1][1] = "red"
        self.faces["top"][1][1] = "blue"
        self.faces["bottom"][1][1] = "green"

        # GUIに表示する面を初期化
        self.current_face = "front"

        # 左側の3D風のキャンバス（left_panel に置く）
        self.canvas = tk.Canvas(left_panel, width=300, height=300, bg="white")
        self.canvas.grid(row=0, column=0, padx=20, pady=20)

        # 右側の展開 図用キャンバス（right_panel に置く）
        self.canvas_right = tk.Canvas(right_panel, width=800, height=600, bg="lightgray")
        self.canvas_right.pack(padx=20, pady=20)

        self.square_size_left = 100  # 各マスのサイズ
        self.square_size_right = 50
        self.draw_face(self.current_face)
        self.draw_unfolded_cube()

        # ボタンを作成（行と列ごとに）
        ctrl = tk.LabelFrame(left_panel, text="Controls")
        ctrl.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="n")

        big = {"font": ("Helvetica", 20), "width": 5, "height": 2, "cursor": "hand2"}

        # 行ボタン（上・中・下）
        tk.Label(ctrl, text="Rows").grid(row=0, column=0, columnspan=3, pady=(0,5))
        tk.Button(ctrl, text="←", command=lambda: self.rotate_row(0, -1), **big).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(ctrl, text="→", command=lambda: self.rotate_row(0,  1), **big).grid(row=1, column=2, padx=5, pady=5)

        tk.Button(ctrl, text="←", command=lambda: self.rotate_row(1, -1), **big).grid(row=2, column=0, padx=5, pady=5)
        tk.Button(ctrl, text="→", command=lambda: self.rotate_row(1,  1), **big).grid(row=2, column=2, padx=5, pady=5)

        tk.Button(ctrl, text="←", command=lambda: self.rotate_row(2, -1), **big).grid(row=3, column=0, padx=5, pady=5)
        tk.Button(ctrl, text="→", command=lambda: self.rotate_row(2,  1), **big).grid(row=3, column=2, padx=5, pady=5)

        # 列ボタン（左・中・右）
        tk.Label(ctrl, text="Cols").grid(row=4, column=0, columnspan=3, pady=(10,5))
        tk.Button(ctrl, text="↑", command=lambda: self.rotate_col(0,  1), **big).grid(row=5, column=0, padx=5, pady=5)
        tk.Button(ctrl, text="↓", command=lambda: self.rotate_col(0, -1), **big).grid(row=6, column=0, padx=5, pady=5)

        tk.Button(ctrl, text="↑", command=lambda: self.rotate_col(1,  1), **big).grid(row=5, column=1, padx=5, pady=5)
        tk.Button(ctrl, text="↓", command=lambda: self.rotate_col(1, -1), **big).grid(row=6, column=1, padx=5, pady=5)

        tk.Button(ctrl, text="↑", command=lambda: self.rotate_col(2,  1), **big).grid(row=5, column=2, padx=5, pady=5)
        tk.Button(ctrl, text="↓", command=lambda: self.rotate_col(2, -1), **big).grid(row=6, column=2, padx=5, pady=5)
        
        # 回るの
        tk.Label(ctrl, text="roal").grid(row=0, column=3, columnspan=3, pady=(10,5))
        tk.Button(ctrl, text="↙︎", command=lambda: self.rotate_guru(0,  -1), **big).grid(row=1, column=3, padx=5, pady=5)
        tk.Button(ctrl, text="↘︎", command=lambda: self.rotate_guru(0, 1), **big).grid(row=1, column=5, padx=5, pady=5)
        tk.Button(ctrl, text="↙︎", command=lambda: self.rotate_guru(1,  -1), **big).grid(row=2, column=3, padx=5, pady=5)
        tk.Button(ctrl, text="↘︎", command=lambda: self.rotate_guru(1, 1), **big).grid(row=2, column=5, padx=5, pady=5)
        tk.Button(ctrl, text="↙︎", command=lambda: self.rotate_guru(2,  -1), **big).grid(row=3, column=3, padx=5, pady=5)
        tk.Button(ctrl, text="↘︎", command=lambda: self.rotate_guru(2, 1), **big).grid(row=3, column=5, padx=5, pady=5)
        
        tk.Button(ctrl, text="shuffle", command=self.shuffle_cube, **big).grid(row=1, column=0, columnspan=3, pady=10)
        tk.Button(ctrl, text="reset", command=self.reset_cube, **big).grid(row=2, column=0, columnspan=3, pady=10)
        tk.Button(ctrl, text="3shuffle", command=self.random_three_moves, **big).grid(row=3, column=0, columnspan=3, pady=10)
        
        self.initial_faces = {face: [row[:] for row in colors] for face, colors in self.faces.items()}
        
        master.bind("<Key>", self.key_pressed)
        
    def start_timer(self):
            if not self.timer_running:
                self.start_time = time.time()
                self.timer_running = True
                self.remaining = 60
                self.update_timer()
        
    def update_timer(self):
            if self.timer_running:
                elapsed = time.time() - self.start_time
                self.remaining = 60 - elapsed

                if self.remaining > 0:                        
                    self.timer_label.config(text=f"{self.remaining:05.2f}")
                    self.master.after(100, self.update_timer)
                else:
                    self.timer_label.config(text="0.00")
                    self.stop_timer()
                    self.status_label.config(text="GAME OVER", bg="white",fg="red")
                        
    def stop_timer(self):
            self.timer_running = False

    def reset_timer(self):
            self.stop_timer()
            self.remaining = 60
            self.timer_label.config(text="60.00")
        
    def is_solved(self):
        for face, grid in self.faces.items():
            color = grid[1][1]
            for row in grid:
                if any(cell != color for cell in row):
                    return False
        self.status_label.config(text="CLEAR!", fg="green")
        return True

    def reset_cube(self):
        # 初期状態に戻す
        self.faces = {face: [row[:] for row in colors] for face, colors in self.initial_faces.items()}
        self.draw_face(self.current_face)
        self.draw_unfolded_cube()
        self.reset_timer()
        self.status_label.config(text="", bg="white")
    
    def shuffle_cube(self, moves=20):
        for _ in range(moves):
            move_type = random.choice(["row", "col", "guru"])  # 3種類から選ぶ
            if move_type == "row":
                    row = random.randint(0, 2)
                    direction = random.choice([-1, 1])
                    self.rotate_row(row, direction)
            elif move_type == "col":
                    col = random.randint(0, 2)
                    direction = random.choice([-1, 1])
                    self.rotate_col(col, direction)
            elif move_type == "guru":
                    guru = random.randint(0, 2)
                    direction = random.choice([-1, 1])
                    self.rotate_guru(guru, direction)
        
    def random_three_moves(self):
        for _ in range(3):
            move_type = random.choice(["row", "col", "guru"])  # 3種類から選ぶ
            if move_type == "row":
                row = random.randint(0, 2)
                direction = random.choice([-1, 1])
                self.rotate_row(row, direction)
            elif move_type == "col":
                col = random.randint(0, 2)
                direction = random.choice([-1, 1])
                self.rotate_col(col, direction)
            elif move_type == "guru":
                    guru = random.randint(0, 2)
                    direction = random.choice([-1, 1])
                    self.rotate_guru(guru, direction)
        self.start_timer()  # ← 追加！


    def key_pressed(self, event):
        key = event.keysym
        if key == "q":       # qキーで上行を左回転
            self.rotate_row(0, -1)
        elif key == "e":    # eキーで上行を右回転
            self.rotate_row(0, 1)
        elif key == "r":       # rキーで左列を上回転
            self.rotate_col(0, 1)
        elif key == "v":     # vキーで左列を下回転
            self.rotate_col(0, -1)
        elif key == "a":        # 'a'キーで中央行を左回転
            self.rotate_row(1, -1)
        elif key == "d":        # 'd'キーで中央行を右回転
            self.rotate_row(1, 1)
        elif key == "t":        # 't'キーで中央列を上回転
            self.rotate_col(1, 1)
        elif key == "b":        # 'b'キーで中央列を下回転
            self.rotate_col(1, -1)
        elif key == "z":        # 'z'キーで下行を左回転
            self.rotate_row(2, -1)
        elif key == "c":        # 'c'キーで下行を右回転
            self.rotate_row(2, 1)
        elif key == "y":        # 'y'キーで右列を上回転
            self.rotate_col(2, 1)
        elif key == "n":        # 'n'キーで右列を下回転
            self.rotate_col(2, -1)
        elif key == "o":
            self.rotate_guru(0, 1)
        elif key == "u":
            self.rotate_guru(0, -1)
        elif key == "l":
            self.rotate_guru(1, 1)
        elif key == "j":
            self.rotate_guru(1, -1)
        elif key == "k":
            self.rotate_guru(2, 1)
        elif key == "m":
            self.rotate_guru(2, -1)
        elif key == "w":
            self.shuffle_cube()
        elif key == "s":
            self.reset_cube()
        elif key == "x":
            self.random_three_moves()
        elif key == "p":   # "u"キーで展開図の表示/非表示を切り替え
            self.toggle_unfolded_cube()
            
    def receive_from_server(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('localhost', 50007))
            s.listen(1)
            print("サーバー待機中...")

            while True:  # ← ここを追加！
                conn, addr = s.accept()
                with conn:
                    print("接続:", addr)
                    while True:
                        data = conn.recv(1024).decode('utf-8')
                        if not data:
                            print("切断されました。再待機します。")
                            break  # ← 内側ループを抜けて再び accept() へ
                        print(f"受信: {data}")
                        self.handle_command(data)
            
    def handle_command(self,cmd):
        if cmd == "←1":
            self.rotate_row(0,-1)
        elif cmd == "→1":
            self.rotate_row(0,1)
        elif cmd == "←2":
            self.rotate_row(1,-1)
        elif cmd == "→2":
            self.rotate_row(1,1)
        elif cmd == "←3":
            self.rotate_row(2,-1)
        elif cmd == "→3":
            self.rotate_row(2,1)
        elif cmd == "↑1":
            self.rotate_col(0,1)
        elif cmd == "↓1":
            self.rotate_col(0,-1)
        elif cmd == "↑2":
            self.rotate_col(1,1)
        elif cmd == "↓2":
            self.rotate_col(1,-1)
        elif cmd == "↑3":
            self.rotate_col(2,1)
        elif cmd == "↓3":
            self.rotate_col(2,-1)
        elif cmd == "↙1":
            self.rotate_guru(0,-1)
        elif cmd == "↘1":
            self.rotate_guru(0,1)
        elif cmd == "↙2":
            self.rotate_guru(1,-1)
        elif cmd == "↘2":
            self.rotate_guru(1,1)
        elif cmd == "↙3":
            self.rotate_guru(2,-1)
        elif cmd == "↘3":
            self.rotate_guru(2,1)
        elif cmd == "S":
            self.reset_cube()
        elif cmd == "F":
            self.start_timer()

    def draw_face(self, face):
        self.canvas.delete("all")
        face_colors = self.faces[face]

        for i in range(3):
            for j in range(3):
                x1 = j * self.square_size_left
                y1 = i * self.square_size_left
                x2 = x1 + self.square_size_left
                y2 = y1 + self.square_size_left
                color = face_colors[i][j]
                self.canvas.create_rectangle(x1, y1, x2, y2, outline="black", fill=color)
                
    def toggle_unfolded_cube(self):
        if self.canvas_right.winfo_ismapped():  # 表示中なら
            self.canvas_right.pack_forget()     # 非表示にする
        else:
            self.canvas_right.pack(padx=20, pady=20)  # 再度表示する
            self.draw_unfolded_cube()  # 再描画

    def draw_unfolded_cube(self):
        self.canvas_right.delete("all")
        positions = {
            "top": (4, 1),
            "left": (1, 4),
            "front": (4, 4),
            "right": (7, 4),
            "back": (10, 4),
            "bottom": (4, 7)
        }

        for face, (col_offset, row_offset) in positions.items():
            face_colors = self.faces[face]
            for i in range(3):
                for j in range(3):
                    x1 = (col_offset + j) * self.square_size_right
                    y1 = (row_offset + i) * self.square_size_right
                    x2 = x1 + self.square_size_right
                    y2 = y1 + self.square_size_right
                    color = face_colors[i][j]
                    self.canvas_right.create_rectangle(x1, y1, x2, y2, outline="black", fill=color)

    def rotate_row(self, row, direction):
        if row == 0:  # 上行を回転
            if direction == 1:  # 右回転
                temp = self.faces["front"][0][:]
                self.faces["front"][0] = self.faces["left"][0][:]
                self.faces["left"][0] = self.faces["back"][0][:]
                self.faces["back"][0] = self.faces["right"][0][:]
                self.faces["right"][0] = temp
                # top 面を90度回転
                self.faces["top"] = self.rotate_face(self.faces["top"], -1)
            else:  # 左回転
                temp = self.faces["front"][0][:]
                self.faces["front"][0] = self.faces["right"][0][:]
                self.faces["right"][0] = self.faces["back"][0][:]
                self.faces["back"][0] = self.faces["left"][0][:]
                self.faces["left"][0] = temp
                # top 面を90度逆回転
                self.faces["top"] = self.rotate_face(self.faces["top"], 1)
        elif row == 1:  # 中央行を回転
            if direction == 1:  # 右回転
                temp = self.faces["front"][1][:]
                self.faces["front"][1] = self.faces["left"][1][:]
                self.faces["left"][1] = self.faces["back"][1][:]
                self.faces["back"][1] = self.faces["right"][1][:]
                self.faces["right"][1] = temp
            else:  # 左回転
                temp = self.faces["front"][1][:]
                self.faces["front"][1] = self.faces["right"][1][:]
                self.faces["right"][1] = self.faces["back"][1][:]
                self.faces["back"][1] = self.faces["left"][1][:]
                self.faces["left"][1] = temp
        elif row == 2:  # 下行を回転
            if direction == 1:  # 右回転
                temp = self.faces["front"][2][:]
                self.faces["front"][2] = self.faces["left"][2][:]
                self.faces["left"][2] = self.faces["back"][2][:]
                self.faces["back"][2] = self.faces["right"][2][:]
                self.faces["right"][2] = temp
                # bottom 面を90度逆回転
                self.faces["bottom"] = self.rotate_face(self.faces["bottom"], 1)
            else:  # 左回転
                temp = self.faces["front"][2][:]
                self.faces["front"][2] = self.faces["right"][2][:]
                self.faces["right"][2] = self.faces["back"][2][:]
                self.faces["back"][2] = self.faces["left"][2][:]
                self.faces["left"][2] = temp
                # bottom 面を90度回転
                self.faces["bottom"] = self.rotate_face(self.faces["bottom"], -1)
        # 更新後に展開図も再描画
        self.draw_face(self.current_face)
        self.draw_unfolded_cube()
        if self.is_solved():
            self.stop_timer()

    def rotate_col(self, col, direction):
        temp = [None] *3
        if col == 0:  # 左列を回転
            if direction == 1:  # 上回転
                for i in range (3):
                    temp[i] = self.faces["front"][i][0]
                for i in range(3):
                    self.faces["front"][i][0] = self.faces["bottom"][i][0]
                for i in range(3):
                    self.faces["bottom"][i][0] = self.faces["back"][2-i][2]
                for i in range(3):
                    self.faces["back"][2-i][2] = self.faces["top"][i][0]
                for i in range(3):
                    self.faces["top"][i][0] = temp[i]
                # left 面を90度回転
                self.faces["left"] = self.rotate_face(self.faces["left"], -1)
            else:  # 下回転
                for i in range(3):
                    temp[i] = self.faces["front"][i][0]
                for i in range(3):
                    self.faces["front"][i][0] = self.faces["top"][i][0]
                for i in range(3):
                    self.faces["top"][i][0] = self.faces["back"][2-i][2]
                for i in range(3):
                    self.faces["back"][2-i][2] = self.faces["bottom"][i][0]
                for i in range(3):
                    self.faces["bottom"][i][0] = temp[i]
                # left 面を90度逆回転
                self.faces["left"] = self.rotate_face(self.faces["left"], 1) 
        elif col == 1:  # 中央列を回転
            if direction == 1:  # 上回転
                for i in range (3):
                    temp[i] = self.faces["front"][i][1]
                for i in range(3):
                    self.faces["front"][i][1] = self.faces["bottom"][i][1]
                for i in range(3):
                    self.faces["bottom"][i][1] = self.faces["back"][2-i][1]
                for i in range(3):
                    self.faces["back"][2-i][1] = self.faces["top"][i][1]
                for i in range(3):
                    self.faces["top"][i][1] = temp[i]
            else:  # 下回転
                for i in range(3):
                    temp[i] = self.faces["front"][i][1]
                for i in range(3):
                    self.faces["front"][i][1] = self.faces["top"][i][1]
                for i in range(3):
                    self.faces["top"][i][1] = self.faces["back"][2-i][1]
                for i in range(3):
                    self.faces["back"][2-i][1] = self.faces["bottom"][i][1]
                for i in range(3):
                    self.faces["bottom"][i][1] = temp[i]
        elif col == 2:  # 右列を回転
            if direction == 1:  # 上回転
                for i in range (3):
                    temp[i] = self.faces["front"][i][2]
                for i in range(3):
                    self.faces["front"][i][2] = self.faces["bottom"][i][2]
                for i in range(3):
                    self.faces["bottom"][i][2] = self.faces["back"][2-i][0]
                for i in range(3):
                    self.faces["back"][2-i][0] = self.faces["top"][i][2]
                for i in range(3):
                    self.faces["top"][i][2] = temp[i]
                # right 面を90度逆回転
                self.faces["right"] = self.rotate_face(self.faces["right"], 1)
            else:  # 下回転
                for i in range(3):
                    temp[i] = self.faces["front"][i][2]
                for i in range(3):
                    self.faces["front"][i][2] = self.faces["top"][i][2]
                for i in range(3):
                    self.faces["top"][i][2] = self.faces["back"][2-i][0]
                for i in range(3):
                    self.faces["back"][2-i][0] = self.faces["bottom"][i][2]
                for i in range(3):
                    self.faces["bottom"][i][2] = temp[i]
                # right 面を90度回転
                self.faces["right"] = self.rotate_face(self.faces["right"], -1)
        # 更新後に展開図も再描画
        self.draw_face(self.current_face)
        self.draw_unfolded_cube()
        if self.is_solved():
            self.stop_timer()
        
    def rotate_guru(self, guru, direction):
        temp = [None] *3
        if guru == 0:  # 上行を回転
            if direction == 1:  # 右回転
                for i in range(3):
                    temp[i] = self.faces["top"][0][i]
                for i in range(3):
                    self.faces["top"][0][i] = self.faces["left"][2-i][0]
                for i in range(3):
                    self.faces["left"][i][0] = self.faces["bottom"][2][i]
                for i in range(3):
                    self.faces["bottom"][2][i] = self.faces["right"][2-i][2]
                for i in range(3):
                    self.faces["right"][i][2] = temp[i]
                #後ろを回す
                self.faces["back"] = self.rotate_face(self.faces["back"], -1)
                    
            else:  # 左回転
                for i in range(3):
                    temp[i] = self.faces["top"][0][i]
                for i in range(3):
                    self.faces["top"][0][i] = self.faces["right"][i][2]
                for i in range(3):
                    self.faces["right"][i][2] = self.faces["bottom"][2][2-i]
                for i in range(3):
                    self.faces["bottom"][2][i] = self.faces["left"][i][0]
                for i in range(3):
                    self.faces["left"][2-i][0] = temp[i]
                #後ろを回す
                self.faces["back"] = self.rotate_face(self.faces["back"], 1)
        elif guru == 1:  # 中央行を回転
            if direction == 1:  # 右回転
                for i in range(3):
                    temp[i] = self.faces["top"][1][i]
                for i in range(3):
                    self.faces["top"][1][i] = self.faces["left"][2-i][1]
                for i in range(3):
                    self.faces["left"][i][1] = self.faces["bottom"][1][i]
                for i in range(3):
                    self.faces["bottom"][1][i] = self.faces["right"][2-i][1]
                for i in range(3):
                    self.faces["right"][i][1] = temp[i]
            else:  # 左回転
                for i in range(3):
                    temp[i] = self.faces["top"][1][i]
                for i in range(3):
                    self.faces["top"][1][i] = self.faces["right"][i][1]
                for i in range(3):
                    self.faces["right"][i][1] = self.faces["bottom"][1][2-i]
                for i in range(3):
                    self.faces["bottom"][1][i] = self.faces["left"][i][1]
                for i in range(3):
                    self.faces["left"][2-i][1] = temp[i]
        elif guru == 2:  # 下行を回転
            if direction == 1:  # 右回転
                for i in range(3):
                    temp[i] = self.faces["top"][2][i]
                for i in range(3):
                    self.faces["top"][2][i] = self.faces["left"][2-i][2]
                for i in range(3):
                    self.faces["left"][i][2] = self.faces["bottom"][0][i]
                for i in range(3):
                    self.faces["bottom"][0][i] = self.faces["right"][2-i][0]
                for i in range(3):
                    self.faces["right"][i][0] = temp[i]
                #後ろを回す
                self.faces["front"] = self.rotate_face(self.faces["front"], 1)
            else:  # 左回転
                for i in range(3):
                    temp[i] = self.faces["top"][2][i]
                for i in range(3):
                    self.faces["top"][2][i] = self.faces["right"][i][0]
                for i in range(3):
                    self.faces["right"][i][0] = self.faces["bottom"][0][2-i]
                for i in range(3):
                    self.faces["bottom"][0][i] = self.faces["left"][i][2]
                for i in range(3):
                    self.faces["left"][2-i][2] = temp[i]
                #後ろを回す
                self.faces["front"] = self.rotate_face(self.faces["front"], -1)
        # 更新後に展開図も再描画
        self.draw_face(self.current_face)
        self.draw_unfolded_cube()
        if self.is_solved():
            self.stop_timer()
        
    def rotate_face(self, face, direction):
        if direction == 1:  # 時計回り
            return [
        [face[2][0], face[1][0], face[0][0]], 
        [face[2][1], face[1][1], face[0][1]], 
        [face[2][2], face[1][2], face[0][2]]   
    ]

        elif direction == -1:  # 反時計回り
            return [
        [face[0][2], face[1][2], face[2][2]], 
        [face[0][1], face[1][1], face[2][1]], 
        [face[0][0], face[1][0], face[2][0]]   
    ]
            
    threading.Thread(target=receive_from_server, daemon=True).start()

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Rubik Cube Omega")

    gui = CubeGUI(root)
    threading.Thread(target=gui.receive_from_server, daemon=True).start()

    root.mainloop()