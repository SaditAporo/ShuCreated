let circleX = 100;
let circleY = 100;
let circleSize = 50;

function setup() {
  createCanvas(600, 600);
  frameRate(30);  // 30 FPSで動作
}

function draw() {
  background(255);

  // 画面の中央に移動
  let targetX = mouseX;
  let targetY = mouseY;

  // 目標位置に円を滑らかに移動させる
  circleX += (targetX - circleX) * 0.05;
  circleY += (targetY - circleY) * 0.05;

  fill(100, 150, 255);
  noStroke();
  ellipse(circleX, circleY, circleSize);

  // テキスト表示
  textSize(32);
  fill(0);
  text('追いかける円', 180, 50);
}