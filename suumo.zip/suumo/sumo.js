let message="ダイナミックトントン相撲";
let message2;
let mode = "normal";
let spmode = "plus";
let x = 0;
let FontA;
let FontBuckupA;
let dakuten = "゛"
let img1;
let img2;
let img12;
let img22;
let img13;
let img23;
let spd = 0;
let haba = 0;
let takasa = 0;
let fontGrow = 50;
let fontGrow2 = 50;
let habaa;
let takasaa;
let rikishi1X;
let rikishi1Y;
let rikishi2X;
let rikishi2Y;
let nigyoume;
let soundhora;
let soundwadaiko;
let soundbyun;
let soundzuza;
let soundkaze;
let soundhyousigi;
let soundflag = false;

function preload() {
    FontA = loadFont('fonts/toryu.ttf');
    FontBuckupA = loadFont('fonts/NotoSansJP-Bold.ttf');
    img1 = loadImage('images/rikisi1.png');
    img2 = loadImage('images/rikisi2.png');
    img12 = loadImage('images/rikisi1-2.png');
    img22 = loadImage('images/rikisi2-2.png');
    img13 = loadImage('images/rikisi1-3.png');
    img23 = loadImage('images/rikisi2-3.png');
    soundhora = loadSound('sounds/Horagai012.mp3');
    soundwadaiko = loadSound('sounds/wadaiko.mp3');
    soundbyun = loadSound('sounds/byun.mp3');
    soundzuza = loadSound('sounds/zuza.mp3');
    soundkaze = loadSound('sounds/kaze.mp3');
    soundhyousigi = loadSound('sounds/hyousigi.mp3');
  }

function setup() {
  let cnv = createCanvas(1400, 1000);
  background(200, 0, 120);
  textSize(50);
  textAlign(CENTER,CENTER);
  cnv.position((windowWidth - width) / 2, (windowHeight - height) / 2); // キャンバスを中央に配置
  text(message,width/2,height/2);
}

function draw() {
    if(mode === "start"){
      hakkeyoi();
    }
    else if(mode === "uwatenage"){
        uwate();
    }
    else if(mode === "shitatenage"){
        shitate();
    }
    else if(mode === "hatakikomi"){
        hataki();
    }
    else if(mode === "normal"){
        nom();
    }
    else if(mode === "animetion"){
        anime();
        if(spmode === "plus"){
          sppl();
        }
        else if(spmode === "minus"){
          spmi();
        }
    }
    else if(mode === "shingi"){
        shingi();
    }
    else if(mode === "doutai"){
        doutai();
    }
    else if(mode === "uwate1"){
        uwate1();
    }
    else if(mode === "uwate2"){
        uwate2();
    }
    else if(mode === "shitate1"){
        shitate1();
    }
    else if(mode === "shitate2"){
        shitate2();
    }
    else if(mode === "kecchaku"){
        kecchaku();
    }
    else if(mode === "hataki1"){
        hataki1();
    }
    else if(mode ==="hataki2"){
        hataki2();
    }
}

// キーが押されたときに反応
function keyPressed() {
  if (key === '1'){
    soundflag = false;
    fontGrow = 50;
    fontGrow2 = 50;
    nigyoume = true;
    mode = "start";
    spd = 0;
    setTimeout(() => {
      nigyoume = false;
    }, 1500); // 1000ms = 1秒
    setTimeout(()=>{
        mode = "animetion";
    },3400);
  }
  if(key === '2'){
    stopAllSounds();
    mode = "shingi";
  }
  if(key === '3'){
    stopAllSounds();
    mode = "doutai";
    fontGrow = 50;
    setTimeout(()=>{
        soundflag = false;
    },1500);
    setTimeout(()=>{
        fontGrow = 50;
        fontGrow2 = 50;
        nigyoume = true;
        mode = "start";
    },5000);
    setTimeout(() => {
        soundflag = false;
        nigyoume = false;
    }, 6500); // 1000ms = 1秒
    setTimeout(()=>{
        soundflag = false;
        mode = "animetion";
    },8400);
  }
  else if (key === 'u') {
    setTimeout(()=>{
        if(spmode === "plus"){
            soundkaze.stop();
            haba = rikishi1X;
            takasa = rikishi1Y;
            habaa=haba;
            takasaa=takasa;
            soundflag = false;
            mode = "uwate1";
        }
        else if(spmode === "minus"){
            soundkaze.stop();
            haba = rikishi2X;
            takasa = rikishi2Y;
            habaa = haba;
            takasaa = takasa;
            soundflag = false;
            mode = "uwate2";
        }

    },1500);
    setTimeout(()=>{
        fontGrow = 50;
        mode = "kecchaku";
    },2900);
    setTimeout(()=>{
        soundflag = false;
    },3300);
    setTimeout(()=>{
        x = -200;
        mode = "uwatenage";
    },4500);
    setTimeout(()=>{
        soundflag = false;
    },5500);
  } 
  else if (key === 's') {
    setTimeout(()=>{
        if(spmode === "plus"){
            soundkaze.stop();
            haba = rikishi1X;
            takasa = rikishi1Y;
            habaa=haba;
            takasaa=takasa;
            soundflag = false;
            mode = "shitate1";
        }
        else if(spmode === "minus"){
            soundkaze.stop();
            haba = rikishi2X;
            takasa = rikishi2Y;
            habaa = haba;
            takasaa = takasa;
            soundflag = false;
            mode = "shitate2";
        }

    },1500);
    setTimeout(()=>{
        fontGrow = 50;
        mode = "kecchaku";
    },2900);
    setTimeout(()=>{
        soundflag = false;
    },3300);
    setTimeout(()=>{
        x = -200;
        mode = "shitatenage";
    },4500);
    setTimeout(()=>{
        soundflag = false;
    },5500);
  } 
  else if (key === 'h') {
    setTimeout(()=>{
        if(spmode === "plus"){
            soundkaze.stop();
            haba = rikishi1X;
            takasa = rikishi1Y;
            habaa=haba;
            takasaa=takasa;
            soundflag = false;
            mode = "hataki1";
        }
        else if(spmode === "minus"){
            soundkaze.stop();
            haba = rikishi2X;
            takasa = rikishi2Y;
            habaa = haba;
            takasaa = takasa;
            soundflag = false;
            mode = "hataki2";
        }

    },1500);
    setTimeout(()=>{
        fontGrow = 50;
        mode = "kecchaku";
    },2900);
    setTimeout(()=>{
        soundflag = false;
    },3300);
    setTimeout(()=>{
        x = -620;
        mode = "hatakikomi";
    },4500);
    setTimeout(()=>{
        soundflag = false;
    },5500);
  }else if (key === 'n' || key === 'N'){
    stopAllSounds();
    soundflag = false;
    mode = "normal";
  }
}

function anime(){
    imageMode(CENTER);       // 画像の中心を基準に描画する
    drawRadialBackground();
    let scaleFactor1 = 1 + 0.1 * sin(frameCount * 0.105); // 1.0〜1.2の間で変化
    let scaleFactor2 = 1 + 0.1 * sin(frameCount * 0.105-PI/2); // 1.0〜1.2の間で変化
    let w = 300 * scaleFactor1; // 幅
    let h = 600 * scaleFactor1; // 高さ
    let i = 300 * scaleFactor2; // 幅
    let k = 600 * scaleFactor2; // 高さ
     rikishi1X = spd + 820;
     rikishi1Y = 500;
     rikishi2X = spd + 585;
     rikishi2Y = 517;
    image(img1, rikishi1X , rikishi1Y , w, h);
    image(img2, rikishi2X , rikishi2Y , i, k);
    if (!soundkaze.isPlaying()) {
        soundkaze.play();
      }
}

function sppl(){
    spd+=10;
    if(spd > 380){
        spmode = "minus";
    }
}
function spmi(){
    spd-=10;
    if(spd < -380){
        spmode = "plus";
    }
}

function shingi(){
    message ="たたいま物言いか入りました";
    dakuten ="゛";
    background(200,0,120); // 背景クリア
    textFont(FontA);
    fill(0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(message,width / 2,  (height / 2)-50);
    message2 ="しはらくお待ちくたさい";
    textFont(FontA);
    fill(0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(message2,(width /2),  (height / 2)+40);
    textFont(FontBuckupA);
    fill(0);
    textSize(70);
    noStroke(); // ← これがポイント！
    text(dakuten,(width /2)-410,  (height / 2)-60);
    textFont(FontBuckupA);
    fill(0);
    textSize(70);
    noStroke(); // ← これがポイント！
    text(dakuten,(width /2)+140,  (height / 2)-60);
    textFont(FontBuckupA);
    fill(0);
    textSize(70);
    noStroke(); // ← これがポイント！
    text(dakuten,(width /2)-300,  (height / 2)+20);
    textFont(FontBuckupA);
    fill(0);
    textSize(70);
    noStroke(); // ← これがポイント！
    text(dakuten,(width /2)+315,  (height / 2)+30);
}
function doutai(){
    background(200,0,120); // 背景クリア
    message = "同体取り直し"
    if (fontGrow < 150) {  // ← 最大サイズに達するまで成長
        fontGrow += 2;
      }

      textSize(fontGrow);
      textFont(FontA);
      fill(255, 215, 0);
      text(message, width/2, height/2);
      if (!soundflag) {
        soundflag = true;
        if (!soundwadaiko.isPlaying()) {
          soundwadaiko.play();
        }
    }
}
function uwate1(){
  drawRadialBackground();
  if (!soundflag) {
    soundflag = true;
    if (!soundbyun.isPlaying()) {
      soundbyun.play();
    }
  }
    imageMode(CENTER); 
    image(img22, habaa-100 , takasaa , 300, 600);
    push();
    haba += 10;
    takasa -= 10;
    translate(haba, takasa);  
    rotate(frameCount*0.3);
    image(img13,0,0,300,600);
    pop();
}
function uwate2(){
  drawRadialBackground();
  if (!soundflag) {
    soundflag = true;
    if (!soundbyun.isPlaying()) {
      soundbyun.play();
    }
  }
    imageMode(CENTER);       // 画像の中心を基準に描画する
    image(img12, habaa+100 , takasaa , 300, 600);
    push();  
    haba -= 10;
    takasa += 10;
    translate(haba, takasa);  
    rotate(frameCount*0.3);
    image(img23,0,0,300,600);
    pop();
}
function shitate1(){
    drawRadialBackground();
    if (!soundflag) {
        soundflag = true;
        if (!soundbyun.isPlaying()) {
          soundbyun.play();
        }
      }
      imageMode(CENTER); 
      image(img22, habaa-100 , takasaa , 300, 600);
      push();
      haba += 10;
      takasa += 10;
      translate(haba, takasa);  
      rotate(frameCount*0.3);
      image(img13,0,0,300,600);
      pop();
  }
  function shitate2(){
    drawRadialBackground();
    if (!soundflag) {
        soundflag = true;
        if (!soundbyun.isPlaying()) {
          soundbyun.play();
        }
      }
      imageMode(CENTER);       // 画像の中心を基準に描画する
      image(img12, habaa+100 , takasaa , 300, 600);
      push();  
      haba -= 10;
      takasa -= 10;
      translate(haba, takasa);  
      rotate(frameCount*0.3);
      image(img23,0,0,300,600);
      pop();
  }
function hataki1(){
    drawRadialBackground();
    if (!soundflag) {
        soundflag = true;
        if (!soundzuza.isPlaying()) {
          soundzuza.play();
        }
      }
    push();  // ←描画状態を保存（重要！）
    imageMode(CENTER); // 画像の中心を基準に描く
    translate(rikishi2X, rikishi2Y+50); // ←画像を描きたい場所へ移動
    rotate(-80.4); 
    image(img23, 0, 0, 300, 600); // ←中心が (0,0) になるよう描画
    pop();   // ←元の状態に戻す（他の描画に影響させない）
    push();  // ←描画状態を保存（重要！）
    imageMode(CENTER); // 画像の中心を基準に描く
    translate(rikishi1X+30, rikishi1Y); // ←画像を描きたい場所へ移動
    rotate(-0.4); 
    image(img12, 0, 0, 300, 600); // ←中心が (0,0) になるよう描画
    pop();
}
function hataki2(){
    drawRadialBackground();
    if (!soundflag) {
        soundflag = true;
        if (!soundzuza.isPlaying()) {
          soundzuza.play();
        }
      }
    push();  // ←描画状態を保存（重要！）
    imageMode(CENTER); // 画像の中心を基準に描く
    translate(rikishi1X, rikishi1Y+90); // ←画像を描きたい場所へ移動
    rotate(30);
    image(img13, 0, 0, 300, 600); // ←中心が (0,0) になるよう描画
    pop();   // ←元の状態に戻す（他の描画に影響させない）
    push();  // ←描画状態を保存（重要！）
    imageMode(CENTER); // 画像の中心を基準に描く
    translate(rikishi2X-20, rikishi2Y); // ←画像を描きたい場所へ移動
    rotate(0.4); 
    image(img22, 0, 0, 300, 600); // ←中心が (0,0) になるよう描画
    pop();
}
function kecchaku(){
    background(200,0,120);
    if (!soundflag) {
        soundflag = true;
        if (!soundwadaiko.isPlaying()) {
          soundwadaiko.play();
        }
      }
    if (fontGrow < 150) {  // ← 最大サイズに達するまで成長
        fontGrow += 2;
      }

      textSize(fontGrow);
      textFont(FontA);
      fill(220, 220, 220);
      text("勝負あり", width/2, height/2);
}

function hakkeyoi(){
  message = "はっけよい";
  message2 = "のこった";
  background(200,0,120);
  if (fontGrow < 150) {  // ← 最大サイズに達するまで成長
    fontGrow += 2;
  }
  textFont(FontA);
  fill(0);
  stroke(0);
  strokeWeight(8);
  textSize(fontGrow);
  text(message,width/2,(height/2)-200);
  if(nigyoume === false){
    if (!soundflag){
        soundflag = true;
        if(!soundhora.isPlaying()){
            soundhora.play();
        }
    }
    if (fontGrow2 < 150) {  // ← 最大サイズに達するまで成長
      fontGrow2 += 2;
    }
    fill(0);
    stroke(0);
    strokeWeight(8);
    textSize(fontGrow2);
    text(message2,width/2,(height/2)+100);
  }
}

function uwate(){
    if(soundflag === false){
        soundflag = true;
        if (!soundhyousigi.isPlaying()) {
            soundhyousigi.play();
          }
        }
    message = "たたいまの決まり手は上手投け";
    drawGradientBackground(); // 背景クリア
    textFont(FontA);
    fill(255, 0, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(message,x-500,height/2);
    textFont(FontBuckupA);
    fill(255, 0, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(dakuten,x+160,(height/2)-20);
    textFont(FontBuckupA);
    fill(255, 0, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(dakuten,x-935,(height/2)-5);
    x += 8;
    if(x>width+1080){
      x=-700;
    }
  }
  function shitate(){
    if(soundflag === false){
        soundflag = true;
        if (!soundhyousigi.isPlaying()) {
            soundhyousigi.play();
          }
        }
    message = "たたいまの決まり手は下手投け";
    drawGradientBackground(); // 背景クリア
    textFont(FontA);
    fill(0, 255, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(message,x-500,height/2);
    textFont(FontBuckupA);
    fill(0, 255, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(dakuten,x+160,(height/2)-20);
    textFont(FontBuckupA);
    fill(0, 255, 0);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(dakuten,x-935,(height/2)-5);
    x += 8;
    if(x>width+1080){
      x=-700;
    }
  }
  function hataki(){
    if(soundflag === false){
        soundflag = true;
    if (!soundhyousigi.isPlaying()) {
        soundhyousigi.play();
      }
    }
    message = "たたいまの決まり手ははたきこみ";
    drawGradientBackground();
    textFont(FontA);
    fill(0,0,255);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(message,x,height/2);
    textFont(FontBuckupA);
    fill(0, 0, 255);
    textSize(90);
    noStroke(); // ← これがポイント！
    text(dakuten,x-480,(height/2)-5);
    x += 8;
    if(x>width+660){
      x=-920;
    }
  }
  function nom(){
    message = "タイナミックトントンすもう";
    drawGradientBackground();
    textFont(FontA);
    let r = 128 + 128 * sin(frameCount*0.03);
    let g = 128 + 128 * sin(frameCount*0.03 + 2);
    let b = 128 + 128 * sin(frameCount*0.03 + 4);
    fill(r, g, b);
    textSize(100);
    noStroke(); // ← これがポイント！
    text(message,width/2,height/2);
    textFont(FontBuckupA);
    fill(r, g, b);
    textSize(100);
    noStroke(); // ← これがポイント！
    text(dakuten,(width/2)+470,(height/2)-30);
    textFont(FontBuckupA);
    fill(r, g, b);
    textSize(100);
    noStroke(); // ← これがポイント！
    text(dakuten,(width/2)-510,height/2);
  }

  function bgnomal(){
    background(255);//白
  }
  function drawRadialBackground() {
    background(50, 0, 80); // ← 最も外側の色をまず全体に塗る,土俵付きグラデ
  
    noStroke();
    for (let r = max(width, height); r > 0; r -= 5) {
      let inter = map(r, max(width, height), 0, 0, 4);
      let c = lerpColor(color(50, 0, 80), color(220, 0, 70), inter);
      fill(c);
      ellipse(width / 2, height / 2, r, r);
    }
  
    stroke(255);
    strokeWeight(8);
    let x1 = width / 2 - 100;
    let x2 = width / 2 + 100;
    line(x1, height / 2 - 60, x1, height / 2 + 60);
    line(x2, height / 2 - 60, x2, height / 2 + 60);
  }
  function drawGradientBackground() {
    for (let y = 0; y < height; y++) {
      let inter = map(y, 0, height, 0, 1);
      let c = lerpColor(color(280, 0, 70), color(160, 0, 120), inter);//ただのグラデ
      stroke(c);
      line(0, y, width, y);
    }
}
function stopAllSounds() {
    soundhora.stop();
    soundkaze.stop();
    soundbyun.stop();
    soundzuza.stop();
    soundkaze.stop();
    soundhyousigi.stop();

  }